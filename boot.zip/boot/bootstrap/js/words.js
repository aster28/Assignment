
   function getwords() {
     
       text2 = word1.value;
       document.getElementById("para").innerHTML += '<p>'+text2
       document.getElementById("words").value = "enter"
}
 
